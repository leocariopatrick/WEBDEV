<!DOCTYPE html>
<html>
<head>
    <title> we CREATE  NOT  DESTROYED</title>
<style type="text/css">
    ul{
        list-style: none;
    text-decoration: none; 
    background-color: #A7D3B5;
    }
    ul li {
    display: inline-block;
    padding: 0px;
    margin-top: 20px;
    margin-bottom: 20px;



}
ul li a{
    text-decoration: none;
    color: #fff;
    padding: 5px 20px;
    border: 1px solid #fff; 
    transition: 0.20s ease;
}
ul li a:hover{
    color: #000;
    }
    }
    h1{
        text-align: center;
        background-color: #6EADA4;
    }
    p{
        margin: 0 px;
        background-color: #F992A8;
        padding: 15px;
        font-size: 30px;
    }
    footer{
    background-color: #A7D3B5;
}
</style>
</head>
<body>

        <div>
            <ul>
                
                <li><a href="">HOME</a></li>
                <li><a href="">ABOUT</a></li>
                <li><a href="">CONTACT</a></li>
            </ul>
        </div>

        <center>
        <div>
         <h1>𝕎𝔼𝕃ℂ𝕆𝕄𝔼 𝕋𝕆  𝕄𝕐  ℙ𝕆ℝ𝔽𝕆𝕃𝕀𝕆 </h1>
    </div>
    <div>
<p>🆃🅷🅴  🆀🆄🅸🅲🅺  🅱🆁🅾🆆🅽  🅵🅾🆇  🅹🆄🅼🅿  🅾🆅🅴🆁  🆃🅷🅴  🅻🅰🆉🆈 🅳🅾🅶</p><br>
<p>[̲̅t][̲̅h][̲̅e] [̲̅q][̲̅u][̲̅i][̲̅c][̲̅k]  [̲̅b][̲̅r][̲̅o][̲̅w][̲̅n]  [̲̅f][̲̅o][̲̅o][̲̅x]  [̲̅j][̲̅u][̲̅m][̲̅p]  [̲̅o][̲̅v][̲̅e][̲̅r] [̲̅t][̲̅h][̲̅e]  [̲̅l][̲̅a][̲̅z][̲̅y]  [̲̅d][̲̅o][̲̅g]</p><br>
<p>🅣🅗🅔  🅠🅤🅘🅒🅚  🅑🅡🅞🅦🅝  🅕🅞🅧   🅙🅤🅜🅟   🅞🅥🅔🅡  🅣🅗🅔  🅛🅐🅩🅨  🅓🅞🅖
</p>
</div>
    </center>
    <center>
    <div>
        <footer> ♚☆  𝐏𝓐𝐓𝓇𝕚ᑕ𝕜 𝕞.  Łｅ𝑜ČΔｒĮό  🐻🐻</footer>
    </div>
    </center>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\laravel\resources\views/welcome.blade.php ENDPATH**/ ?>