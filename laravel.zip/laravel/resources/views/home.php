<!DOCTYPE html>
<html>
<head>
	<title> My  first   WEBSITE</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	<style type="text/css">
		*{
		background-image: url(images/bg.png);
		background-repeat: no-repeat;
		background-size: cover;
		background-position: center;
	background-attachment: fixed;
}
			ul{
	list-style: none;
	text-decoration: none; 
	margin: 0px;
	background-color: #A7D3B5;
} 
ul li {
	display: inline-block;
	padding: 0px;
	margin-bottom: 20px;


}
ul li a{
 	text-decoration: none;
 	color: #fff;
 	padding:  10px 30px;
 	border: 1px solid #fff; 
 	transition: 0.20s ease;
}
ul li a:hover{
	color: #10A421;
	}
.gallery{
	width: 100px;
	height: 100px;
	margin-top: 20px;
	margin-bottom: 0px;
	margin-right: 700px;
}
footer{
	background-color: #A7D3B5;
	font-size: 40px;
	color: #ffffff;
	}
	h1{
		text-align: center;
	}
	.gallery1{
		display: inline-block;
		width: 350px;
		height: 400px;
		}
		.gallery1 img{
	width: 230px;
	padding: 5px;
	filter: grayscale(100%);
	transition: 1s;
	border-radius: 20px;
}
.gallery1 img:hover{
filter: grayscale(0);
transform: scale(1.1);
}

	</style>
</head>
<body>
	<div>
		<ul>
		<img src="images/logo.png"  class="gallery">
			<li><a href="home"><i class="fa fa-home"></i>&nbsp;🅷🅾🅼🅴</a></li>
			<li><a href="about"><i class="fa fa-user"></i>&nbsp;🅰🅱🅾🆄🆃</a></li>
			<li><a href="contact"><i class="fa fa-phone"></i>&nbsp;🅲🅾🅽🆃🅰🅲🆃</a></li>

		</ul>
	</div>
	<div>
		 <h1>🅼🆈  🅿🅾🆁🆃🅵🅾🅻🅸🅾</h1>
	</div>
	<center>
		<div>
			<a href=""><img src="images/1.jpg" class="gallery1"></a>
			<a href=""><img src="images/2.jpg" class="gallery1"></a>
			<a href=""><img src="images/3.jpg" class="gallery1"></a>
			<a href=""><img src="images/4.jpg" class="gallery1"></a>
		
		</div>
		</center>
	<center>
	<div>
		<footer> ░P░A░T░R░I░C░K░ ░M░ ░L░E░O░C░A░R░I░O░</footer>
	</div>
	</center>

</body>
</html>